<?php

/*
* Comment Author E-Mail Validation
*/

class SFWeverify {


}

?>